const DB_NAME = 'DroneFolioDB';
const DB_VERSION = 1;
const STORE_NAME = 'image_files';

let dbPromise: Promise<IDBDatabase> | null = null;

const initDB = (): Promise<IDBDatabase> => {
  if (dbPromise) {
    return dbPromise;
  }

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('IndexedDB error:', request.error);
      dbPromise = null; // Allow retrying
      reject('Error opening database');
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });

  return dbPromise;
};

export const setFile = async (key: string, file: File | Blob): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    store.put(file, key);
    
    transaction.oncomplete = () => {
      resolve();
    };
    
    transaction.onerror = () => {
      console.error('Transaction error:', transaction.error);
      reject(transaction.error);
    };
  });
};

export const getFile = async (key: string): Promise<File | Blob | null> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        // This case should ideally not happen if onupgradeneeded has run
        console.warn(`Object store '${STORE_NAME}' not found.`);
        return resolve(null);
      }
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(key);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        console.error('Get file request error:', request.error);
        reject(request.error);
      };
    });
};

export const deleteFile = async (key: string): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    store.delete(key);
    
    transaction.oncomplete = () => {
      resolve();
    };
    
    transaction.onerror = () => {
      console.error('Delete transaction error:', transaction.error);
      reject(transaction.error);
    };
  });
};