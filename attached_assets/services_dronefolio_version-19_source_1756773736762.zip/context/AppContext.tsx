import React, { createContext, useState, useContext, ReactNode, useMemo, useCallback, useEffect } from 'react';
import { MediaItem, MediaType } from '../types';
import { INITIAL_MEDIA_ITEMS, DEFAULT_HERO_IMAGE, DEFAULT_FOOTER_IMAGE } from '../constants';
import * as db from '../utils/db';

export type MediaTypeFilter = MediaType | 'All';
export type LocationFilter = string | 'All';

interface AppContextType {
  isAuthenticated: boolean;
  mediaItems: MediaItem[];
  isLoginModalOpen: boolean;
  isUploadModalOpen: boolean;
  login: (password: string) => boolean;
  logout: () => void;
  updateAdminPassword: (oldPass: string, newPass: string) => boolean;
  addMediaItems: (items: Array<{ title: string; location: string; type: MediaType; file?: File; videoUrl?: string }>) => Promise<void>;
  deleteMediaItem: (id: string) => Promise<void>;
  updateMediaItem: (id: string, updates: { title: string; location: string; type: MediaType; videoUrl?: string; newFile?: File }) => Promise<void>;
  setLoginModalOpen: (isOpen: boolean) => void;
  setUploadModalOpen: (isOpen: boolean) => void;
  selectedType: MediaTypeFilter;
  setSelectedType: (type: MediaTypeFilter) => void;
  selectedLocation: LocationFilter;
  setSelectedLocation: (location: LocationFilter) => void;
  locations: string[];
  heroImageUrl: string;
  setHeroImage: (file: File) => Promise<void>;
  footerImageUrl: string;
  setFooterImage: (file: File) => Promise<void>;
  xUrl: string;
  setXUrl: (url: string) => void;
  youtubeUrl: string;
  setYoutubeUrl: (url: string) => void;
  personalUrl: string;
  setPersonalUrl: (url: string) => void;
  isContactModalOpen: boolean;
  setContactModalOpen: (isOpen: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoginModalOpen, setLoginModalOpen] = useState<boolean>(false);
  const [isUploadModalOpen, setUploadModalOpen] = useState<boolean>(false);
  const [isContactModalOpen, setContactModalOpen] = useState<boolean>(false);
  const [selectedType, setSelectedType] = useState<MediaTypeFilter>('All');
  const [selectedLocation, setSelectedLocation] = useState<LocationFilter>('All');
  
  const [mediaItems, setMediaItems] = useState<MediaItem[]>(INITIAL_MEDIA_ITEMS);
  const [heroImageUrl, setHeroImageUrl] = useState<string>(DEFAULT_HERO_IMAGE);
  const [footerImageUrl, setFooterImageUrl] = useState<string>(DEFAULT_FOOTER_IMAGE);

  const [xUrl, setXUrlState] = useState<string>(() => localStorage.getItem('dronefolio-x') || '');
  const [youtubeUrl, setYoutubeUrlState] = useState<string>(() => localStorage.getItem('dronefolio-youtube') || '');
  const [personalUrl, setPersonalUrlState] = useState<string>(() => localStorage.getItem('dronefolio-personal') || '');
  
  const [adminPassword, setAdminPassword] = useState<string>(() => {
    const storedPassword = localStorage.getItem('dronefolio-password');
    if (storedPassword) {
        return storedPassword;
    }
    // Set default password if not found
    localStorage.setItem('dronefolio-password', 'password123');
    return 'password123';
  });

  // Effect to load all data from storage on initial mount
  useEffect(() => {
    let heroUrl: string | undefined;
    let footerUrl: string | undefined;
    const mediaObjectUrls: string[] = [];

    const loadData = async () => {
      // Load hero and footer images from IndexedDB
      const heroFile = await db.getFile('hero-image');
      if (heroFile) {
        heroUrl = URL.createObjectURL(heroFile);
        setHeroImageUrl(heroUrl);
      }
      const footerFile = await db.getFile('footer-image');
      if (footerFile) {
        footerUrl = URL.createObjectURL(footerFile);
        setFooterImageUrl(footerUrl);
      }

      // Load media items metadata from localStorage and files from IndexedDB
      const storedMeta = localStorage.getItem('dronefolio-media');
      if (storedMeta) {
        try {
          const mediaMeta = JSON.parse(storedMeta);
          
          const hydratedItems = await Promise.all(mediaMeta.map(async (meta: any) => {
            if (meta.type === MediaType.VIDEO) {
              return meta as MediaItem;
            }
            if (!meta.id) return null; // Skip malformed entries

            const file = await db.getFile(meta.id);
            if (file) {
              const objectUrl = URL.createObjectURL(file);
              mediaObjectUrls.push(objectUrl);
              return { ...meta, url: objectUrl } as MediaItem;
            }
            return { ...meta, url: '' } as MediaItem; // File missing from DB
          }));
          setMediaItems(hydratedItems.filter(Boolean) as MediaItem[]);
        } catch (error) {
           console.error("Failed to parse or hydrate media items:", error);
           localStorage.removeItem('dronefolio-media'); // Clear potentially corrupt data
        }
      }
    };

    loadData();

    // Cleanup object URLs on unmount
    return () => {
      if (heroUrl) URL.revokeObjectURL(heroUrl);
      if (footerUrl) URL.revokeObjectURL(footerUrl);
      mediaObjectUrls.forEach(url => URL.revokeObjectURL(url));
    };
  }, []);

  // Effect to persist media item METADATA to localStorage whenever they change
  useEffect(() => {
    try {
      const storableMediaItems = mediaItems.map(item => {
        if (item.type === MediaType.VIDEO) {
          return item; // Keep full item for videos
        }
        // For images, store everything except the blob URL
        const { url, ...metaWithId } = item;
        return metaWithId;
      });
      localStorage.setItem('dronefolio-media', JSON.stringify(storableMediaItems));
    } catch (error) {
      console.error("Failed to save media items metadata to localStorage", error);
    }
  }, [mediaItems]);


  const locations = useMemo(() => {
    const allLocations = mediaItems.map(item => item.location);
    return [...new Set(allLocations)].sort();
  }, [mediaItems]);

  const login = useCallback((password: string): boolean => {
    if (password === adminPassword) {
        setIsAuthenticated(true);
        setLoginModalOpen(false);
        return true;
    }
    return false;
  }, [adminPassword]);
  
  const logout = useCallback(() => {
    setIsAuthenticated(false);
    setUploadModalOpen(false);
  }, []);

  const updateAdminPassword = useCallback((oldPass: string, newPass: string): boolean => {
    if (oldPass === adminPassword) {
        setAdminPassword(newPass);
        localStorage.setItem('dronefolio-password', newPass);
        return true;
    }
    return false;
  }, [adminPassword]);

  const addMediaItems = useCallback(async (items: Array<{ title: string; location: string; type: MediaType; file?: File; videoUrl?: string }>) => {
    const newItemsWithIds: MediaItem[] = [];

    for (const [index, item] of items.entries()) {
        const id = `${Date.now()}-${index}`;
        let newItem: MediaItem | null = null;
        if (item.type !== MediaType.VIDEO && item.file) {
            await db.setFile(id, item.file);
            const objectUrl = URL.createObjectURL(item.file);
            newItem = {
                title: item.title,
                location: item.location,
                type: item.type,
                id,
                url: objectUrl,
            };
        } else if (item.type === MediaType.VIDEO && item.videoUrl) {
            newItem = {
                title: item.title,
                location: item.location,
                type: item.type,
                id,
                url: item.videoUrl,
            };
        }
        if(newItem) newItemsWithIds.push(newItem);
    }
    
    setMediaItems(prevItems => [...newItemsWithIds, ...prevItems]);
  }, []);

  const deleteMediaItem = useCallback(async (id: string) => {
    const itemToDelete = mediaItems.find(item => item.id === id);
    if (!itemToDelete) return;

    // Revoke object URL to prevent memory leaks
    if (itemToDelete.type !== MediaType.VIDEO && itemToDelete.url.startsWith('blob:')) {
      URL.revokeObjectURL(itemToDelete.url);
    }

    // Delete file from IndexedDB if it's not a video
    if (itemToDelete.type !== MediaType.VIDEO) {
      await db.deleteFile(id);
    }
    
    setMediaItems(prevItems => prevItems.filter(item => item.id !== id));
  }, [mediaItems]);

  const updateMediaItem = useCallback(async (id: string, updates: { title: string; location: string; type: MediaType; videoUrl?: string; newFile?: File }) => {
    const itemIndex = mediaItems.findIndex(item => item.id === id);
    if (itemIndex === -1) return;

    const oldItem = mediaItems[itemIndex];
    let newUrl = oldItem.url;

    // Handle file replacement
    if (updates.newFile) {
      // Revoke old blob url
      if (oldItem.type !== MediaType.VIDEO && oldItem.url.startsWith('blob:')) {
        URL.revokeObjectURL(oldItem.url);
      }
      // Set new file in DB and create new blob url
      await db.setFile(id, updates.newFile);
      newUrl = URL.createObjectURL(updates.newFile);
    } else if (updates.type === MediaType.VIDEO && updates.videoUrl) {
      newUrl = updates.videoUrl;
      // If type changed from image to video, delete the old file from DB
      if (oldItem.type !== MediaType.VIDEO) {
        await db.deleteFile(id);
        if (oldItem.url.startsWith('blob:')) {
          URL.revokeObjectURL(oldItem.url);
        }
      }
    }
    
    const updatedItem: MediaItem = {
      ...oldItem,
      title: updates.title,
      location: updates.location,
      type: updates.type,
      url: newUrl,
    };

    setMediaItems(prevItems => {
      const newItems = [...prevItems];
      newItems[itemIndex] = updatedItem;
      return newItems;
    });
  }, [mediaItems]);

  const setHeroImage = useCallback(async (file: File) => {
    await db.setFile('hero-image', file);
    setHeroImageUrl(prevUrl => {
      if (prevUrl && prevUrl.startsWith('blob:')) {
        URL.revokeObjectURL(prevUrl);
      }
      return URL.createObjectURL(file);
    });
  }, []);
  
  const setFooterImage = useCallback(async (file: File) => {
    await db.setFile('footer-image', file);
    setFooterImageUrl(prevUrl => {
      if (prevUrl && prevUrl.startsWith('blob:')) {
        URL.revokeObjectURL(prevUrl);
      }
      return URL.createObjectURL(file);
    });
  }, []);
  
  const setXUrl = useCallback((url: string) => {
    localStorage.setItem('dronefolio-x', url);
    setXUrlState(url);
  }, []);
  
  const setYoutubeUrl = useCallback((url: string) => {
    localStorage.setItem('dronefolio-youtube', url);
    setYoutubeUrlState(url);
  }, []);

  const setPersonalUrl = useCallback((url: string) => {
    localStorage.setItem('dronefolio-personal', url);
    setPersonalUrlState(url);
  }, []);


  const contextValue = useMemo(() => ({
    isAuthenticated,
    mediaItems,
    isLoginModalOpen,
    isUploadModalOpen,
    isContactModalOpen,
    login,
    logout,
    updateAdminPassword,
    addMediaItems,
    deleteMediaItem,
    updateMediaItem,
    setLoginModalOpen,
    setUploadModalOpen,
    setContactModalOpen,
    selectedType,
    setSelectedType,
    selectedLocation,
    setSelectedLocation,
    locations,
    heroImageUrl,
    setHeroImage,
    footerImageUrl,
    setFooterImage,
    xUrl,
    setXUrl,
    youtubeUrl,
    setYoutubeUrl,
    personalUrl,
    setPersonalUrl,
  }), [
    isAuthenticated, mediaItems, isLoginModalOpen, isUploadModalOpen, isContactModalOpen,
    selectedType, selectedLocation, locations, heroImageUrl, footerImageUrl, 
    xUrl, youtubeUrl, personalUrl, login, logout, addMediaItems, setHeroImage, 
    setFooterImage, setXUrl, setYoutubeUrl, setPersonalUrl, setLoginModalOpen, setUploadModalOpen, setContactModalOpen,
    setSelectedType, setSelectedLocation, updateAdminPassword, deleteMediaItem, updateMediaItem
  ]);

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
