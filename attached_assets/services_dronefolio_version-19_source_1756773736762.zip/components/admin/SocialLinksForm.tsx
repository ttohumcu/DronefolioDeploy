import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import Input from '../ui/Input';
import Button from '../ui/Button';

const SocialLinksForm: React.FC = () => {
    const { xUrl, youtubeUrl, personalUrl, setXUrl, setYoutubeUrl, setPersonalUrl } = useAppContext();

    const [currentXUrl, setCurrentXUrl] = useState(xUrl);
    const [currentYoutubeUrl, setCurrentYoutubeUrl] = useState(youtubeUrl);
    const [currentPersonalUrl, setCurrentPersonalUrl] = useState(personalUrl);
    const [success, setSuccess] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setXUrl(currentXUrl);
        setYoutubeUrl(currentYoutubeUrl);
        setPersonalUrl(currentPersonalUrl);
        setSuccess('Social links updated successfully!');

        setTimeout(() => {
            setSuccess('');
        }, 3000);
    };

    return (
        <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">Update Social Links</h3>
            {success && <p className="text-green-400 bg-green-900/50 p-3 rounded-md text-center text-sm">{success}</p>}
            <form onSubmit={handleSubmit} className="space-y-6">
                <Input
                    id="x-url"
                    label="X (Twitter) Profile URL"
                    type="url"
                    value={currentXUrl}
                    onChange={(e) => setCurrentXUrl(e.target.value)}
                    placeholder="https://x.com/yourprofile"
                />
                <Input
                    id="youtube-url"
                    label="YouTube Channel URL"
                    type="url"
                    value={currentYoutubeUrl}
                    onChange={(e) => setCurrentYoutubeUrl(e.target.value)}
                    placeholder="https://youtube.com/yourchannel"
                />
                <Input
                    id="personal-url"
                    label="Personal Page URL"
                    type="url"
                    value={currentPersonalUrl}
                    onChange={(e) => setCurrentPersonalUrl(e.target.value)}
                    placeholder="https://your-site.com"
                />
                <Button type="submit" className="w-full">
                    Save Social Links
                </Button>
            </form>
        </div>
    );
};

export default SocialLinksForm;