import React from 'react';
import { MediaItem, MediaType } from '../../types';
import { useAppContext } from '../../context/AppContext';

interface PortfolioItemProps {
  item: MediaItem;
  onClick: () => void;
  onEdit: (item: MediaItem) => void;
  onDelete: (item: MediaItem) => void;
}

const getYouTubeThumbnail = (url: string): string => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    const videoId = (match && match[2].length === 11) ? match[2] : null;
    return videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : 'https://picsum.photos/seed/error/480/360';
};

const TypeIcon: React.FC<{ type: MediaType }> = ({ type }) => {
    const iconMap: Record<MediaType, React.ReactElement> = {
        [MediaType.PHOTO_4K]: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>,
        [MediaType.PANORAMA_180]: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18.8 3.2a10 10 0 1 0 0 17.6"></path></svg>,
        [MediaType.PANORAMA_360]: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.5 0 4.7.9 6.4 2.3"></path><path d="M21 12a9 9 0 0 0-9-9"></path><path d="m15.5 13.5-1.5 1.5-3-3-1.5 1.5"></path></svg>,
        [MediaType.VIDEO]: <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>,
    };
    return iconMap[type];
};


const PortfolioItem: React.FC<PortfolioItemProps> = ({ item, onClick, onEdit, onDelete }) => {
    const { isAuthenticated } = useAppContext();
    const thumbnailUrl = item.type === MediaType.VIDEO ? getYouTubeThumbnail(item.url) : item.url;
    
  return (
    <div className="break-inside-avoid group relative cursor-pointer overflow-hidden rounded-lg shadow-lg" onClick={onClick}>
        {isAuthenticated && (
          <div className="absolute top-2 left-2 flex space-x-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={(e) => { e.stopPropagation(); onEdit(item); }}
              className="p-2 bg-blue-600/80 hover:bg-blue-500 rounded-full text-white backdrop-blur-sm"
              aria-label="Edit item"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onDelete(item); }}
              className="p-2 bg-red-600/80 hover:bg-red-500 rounded-full text-white backdrop-blur-sm"
              aria-label="Delete item"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
            </button>
          </div>
        )}
        <img
          src={thumbnailUrl}
          alt={item.title}
          className="w-full h-auto object-cover transition-transform duration-500 ease-in-out group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent transition-opacity duration-300"></div>
        <div className="absolute inset-0 flex flex-col justify-end p-4 text-white">
          <div className="absolute top-3 right-3 bg-black/50 p-2 rounded-full backdrop-blur-sm">
            <TypeIcon type={item.type} />
          </div>
          <h3 className="text-lg font-bold transform-gpu transition-transform duration-300 translate-y-4 group-hover:translate-y-0">{item.title}</h3>
          <p className="text-sm text-gray-300 opacity-0 transition-opacity duration-300 group-hover:opacity-100">{item.location}</p>
        </div>
        {item.type === MediaType.VIDEO && (
             <div className="absolute inset-0 flex items-center justify-center">
                 <div className="w-16 h-16 bg-black/50 rounded-full flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                     <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd"></path></svg>
                 </div>
            </div>
        )}
    </div>
  );
};

export default PortfolioItem;
