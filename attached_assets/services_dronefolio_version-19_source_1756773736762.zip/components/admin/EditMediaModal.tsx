import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { MediaItem, MediaType } from '../../types';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';

interface EditMediaModalProps {
  isOpen: boolean;
  onClose: () => void;
  mediaItem: MediaItem | null;
}

const EditMediaModal: React.FC<EditMediaModalProps> = ({ isOpen, onClose, mediaItem }) => {
  const { updateMediaItem } = useAppContext();
  
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<MediaType>(MediaType.PHOTO_4K);
  const [newFile, setNewFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (mediaItem) {
      setTitle(mediaItem.title);
      setLocation(mediaItem.location);
      setType(mediaItem.type);
      setVideoUrl(mediaItem.type === MediaType.VIDEO ? mediaItem.url : '');
      setNewFile(null);
      setError('');
    }
  }, [mediaItem]);

  if (!isOpen || !mediaItem) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setNewFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!title || !location || (type === MediaType.VIDEO && !videoUrl)) {
      setError('Please fill out all required fields.');
      return;
    }

    setIsSubmitting(true);
    try {
      await updateMediaItem(mediaItem.id, { title, location, type, videoUrl, newFile: newFile ?? undefined });
      onClose();
    } catch (err) {
      console.error("Failed to update media item:", err);
      setError("An error occurred while saving. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="max-w-xl w-full mx-auto bg-gray-800 rounded-lg border border-gray-700 relative flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-700 flex justify-between items-center">
            <h2 className="text-2xl font-bold">Edit Media</h2>
            <button 
                onClick={onClose} 
                className="text-gray-400 hover:text-white transition-colors p-2 rounded-full"
                aria-label="Close"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        
        <div className="p-6 overflow-y-auto">
            {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-md text-center text-sm mb-4">{error}</p>}
            <form onSubmit={handleSubmit} className="space-y-6">
              <Input id="title" label="Title" type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
              <Input id="location" label="Location" type="text" value={location} onChange={(e) => setLocation(e.target.value)} required />
              <Select id="type" label="Media Type" value={type} onChange={(e) => setType(e.target.value as MediaType)}>
                  {Object.values(MediaType).map((mediaType) => (
                      <option key={mediaType} value={mediaType}>{mediaType}</option>
                  ))}
              </Select>

              {type === MediaType.VIDEO ? (
                  <Input id="videoUrl" label="YouTube URL" type="url" value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." />
              ) : (
                  <div>
                      <label htmlFor="file-upload" className="block text-sm font-medium text-gray-300 mb-1">
                          Replace Image File (Optional)
                      </label>
                      <img src={mediaItem.url} alt="Current image" className="rounded-md max-h-40 w-auto mb-2" />
                      <input id="file-upload" type="file" accept="image/*" onChange={handleFileChange} className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700" />
                      {newFile && <p className="mt-2 text-xs text-gray-400">New file selected: {newFile.name}</p>}
                  </div>
              )}
              
              <div className="flex justify-end space-x-4 pt-4">
                <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </form>
        </div>
      </div>
    </div>
  );
};

export default EditMediaModal;
