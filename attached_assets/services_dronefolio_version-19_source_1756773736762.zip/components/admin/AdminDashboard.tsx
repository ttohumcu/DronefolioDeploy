import React, { useState } from 'react';
import UploadMediaForm from './UploadMediaForm';
import AppearanceForm from './AppearanceForm';
import SocialLinksForm from './SocialLinksForm';
import SecurityForm from './SecurityForm';

interface AdminDashboardProps {
  onClose: () => void;
}

type AdminTab = 'upload' | 'appearance' | 'social' | 'security';

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('upload');
  
  const baseTabClasses = 'px-4 py-2 text-sm font-medium rounded-t-lg transition-colors focus:outline-none';
  const activeTabClasses = 'bg-gray-700 text-white';
  const inactiveTabClasses = 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white';

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="max-w-3xl w-full mx-auto bg-gray-800 rounded-lg border border-gray-700 relative flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        <button 
            onClick={onClose} 
            className="absolute top-2 right-2 text-gray-400 hover:text-white transition-colors p-2 rounded-full z-20"
            aria-label="Close"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <div className="px-8 pt-6 border-b border-gray-700">
            <h2 className="text-2xl font-bold mb-4">Admin Settings</h2>
            <div className="flex space-x-1">
                <button 
                    onClick={() => setActiveTab('upload')}
                    className={`${baseTabClasses} ${activeTab === 'upload' ? activeTabClasses : inactiveTabClasses}`}
                    aria-current={activeTab === 'upload' ? 'page' : undefined}
                >
                    Uploads
                </button>
                 <button 
                    onClick={() => setActiveTab('appearance')}
                    className={`${baseTabClasses} ${activeTab === 'appearance' ? activeTabClasses : inactiveTabClasses}`}
                    aria-current={activeTab === 'appearance' ? 'page' : undefined}
                >
                    Appearance
                </button>
                 <button 
                    onClick={() => setActiveTab('social')}
                    className={`${baseTabClasses} ${activeTab === 'social' ? activeTabClasses : inactiveTabClasses}`}
                    aria-current={activeTab === 'social' ? 'page' : undefined}
                >
                    Socials
                </button>
                <button 
                    onClick={() => setActiveTab('security')}
                    className={`${baseTabClasses} ${activeTab === 'security' ? activeTabClasses : inactiveTabClasses}`}
                    aria-current={activeTab === 'security' ? 'page' : undefined}
                >
                    Security
                </button>
            </div>
        </div>

        <div className="p-8 overflow-y-auto bg-gray-700/20">
            {activeTab === 'upload' && <UploadMediaForm />}
            {activeTab === 'appearance' && <AppearanceForm />}
            {activeTab === 'social' && <SocialLinksForm />}
            {activeTab === 'security' && <SecurityForm />}
        </div>

        <div className="px-8 py-4 bg-gray-900/50 border-t border-gray-700 rounded-b-lg text-center text-xs text-gray-400">
          <p>
            <strong>Note:</strong> All portfolio data is stored locally in your browser. 
            Clearing site data will permanently delete your uploads and settings.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;