import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { useAppContext } from '../../context/AppContext';
import { MediaItem, MediaType } from '../../types';
import { fileToBase64 } from '../../utils/file';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Button from '../ui/Button';

const UploadMediaForm: React.FC = () => {
  const { addMediaItems } = useAppContext();
  
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<MediaType>(MediaType.PHOTO_4K);
  const [files, setFiles] = useState<File[]>([]);
  const [videoUrl, setVideoUrl] = useState('');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
      setError('');
      setSuccess('');
    }
  };

  const handleAskAI = async () => {
    if (files.length === 0) {
        setError("Please select an image first to ask AI.");
        return;
    }
    setError('');
    setIsGenerating(true);
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const file = files[0];
        const base64Image = (await fileToBase64(file)).split(',')[1];

        const imagePart = {
            inlineData: {
                mimeType: file.type,
                data: base64Image,
            },
        };

        const textPart = {
            text: "Analyze this image of a location taken by a drone. Provide a creative, inspiring title for it and identify the specific location (e.g., city, state, country, or natural landmark). Respond in JSON."
        };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { 
                            type: Type.STRING,
                            description: "A creative and inspiring title for the image, under 10 words."
                        },
                        location: { 
                            type: Type.STRING,
                            description: "The geographical location depicted in the image, like 'Big Sur, California' or 'Cliffs of Moher, Ireland'."
                        },
                    },
                    required: ["title", "location"],
                },
            },
        });

        const parsedResponse = JSON.parse(response.text);
        if (parsedResponse.title) setTitle(parsedResponse.title);
        if (parsedResponse.location) setLocation(parsedResponse.location);

    } catch (err) {
        console.error("Gemini API error:", err);
        setError("AI suggestion failed. Please try again or enter details manually.");
    } finally {
        setIsGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if(!title || !location) {
        setError('Please fill out the title and location for all items.');
        return;
    }
    
    if (type === MediaType.VIDEO) {
        if (!videoUrl) {
            setError('Please provide a YouTube video URL.');
            return;
        }
        const newItem = { title, location, type, videoUrl };
        await addMediaItems([newItem]);
        setSuccess('Media item added successfully!');
    } else {
        if (files.length === 0) {
            setError('Please select one or more image files to upload.');
            return;
        }
        
        const newItems = files.map((file, index) => ({
            title: files.length > 1 ? `${title} (${index + 1})` : title,
            location,
            type,
            file,
        }));

        await addMediaItems(newItems);
        setSuccess(`${files.length} media item(s) added successfully!`);
    }
    
    // Reset form
    setTitle('');
    setLocation('');
    setType(MediaType.PHOTO_4K);
    setFiles([]);
    setVideoUrl('');
    const fileInput = document.getElementById('file-upload') as HTMLInputElement;
    if (fileInput) fileInput.value = '';

    setTimeout(() => setSuccess(''), 3000);
  };

  return (
    <div className="space-y-6">
        <h3 className="text-xl font-bold text-white">Add to Portfolio</h3>
        {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-md text-center text-sm">{error}</p>}
        {success && <p className="text-green-400 bg-green-900/50 p-3 rounded-md text-center text-sm">{success}</p>}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Input id="title" label="Title / Batch Name" type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
             { type !== MediaType.VIDEO && (
                 <Button type="button" onClick={handleAskAI} disabled={isGenerating || files.length === 0} variant="secondary" className="w-full text-sm py-1">
                    {isGenerating ? 'Analyzing...' : '✨ Ask AI for Title & Location'}
                 </Button>
            )}
          </div>
          <Input id="location" label="Location" type="text" value={location} onChange={(e) => setLocation(e.target.value)} required />
          <Select id="type" label="Media Type" value={type} onChange={(e) => setType(e.target.value as MediaType)}>
              {Object.values(MediaType).map((mediaType) => (
                  <option key={mediaType} value={mediaType}>{mediaType}</option>
              ))}
          </Select>

          {type === MediaType.VIDEO ? (
              <Input id="videoUrl" label="YouTube URL" type="url" value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." />
          ) : (
              <div>
                  <label htmlFor="file-upload" className="block text-sm font-medium text-gray-300 mb-1">
                      Image File(s)
                  </label>
                  <input id="file-upload" type="file" accept="image/*" multiple onChange={handleFileChange} className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700" />
                  {files.length > 0 && (
                    <div className="mt-3 text-xs text-gray-400 bg-gray-900/50 p-2 rounded-md">
                        <p className="font-semibold mb-1">{files.length} file(s) selected:</p>
                        <ul className="list-disc list-inside max-h-24 overflow-y-auto space-y-1 pl-2">
                        {files.map(f => <li key={f.name} className="truncate">{f.name}</li>)}
                        </ul>
                    </div>
                  )}
              </div>
          )}
          
          <Button type="submit" className="w-full">
              Add to Portfolio
          </Button>
        </form>
    </div>
  );
};

export default UploadMediaForm;