import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import Input from '../ui/Input';
import Button from '../ui/Button';

interface LoginPageProps {
  onClose: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onClose }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAppContext();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(password);
    if (success) {
      setError('');
      // No need to call onClose, login() handles it via context
    } else {
      setError('Invalid password.');
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-md p-8 space-y-6 bg-gray-800 rounded-lg shadow-lg border border-gray-700 relative"
        onClick={e => e.stopPropagation()}
      >
         <button 
            onClick={onClose} 
            className="absolute top-2 right-2 text-gray-400 hover:text-white transition-colors p-2 rounded-full"
            aria-label="Close"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <div className="text-center">
            <div className="flex justify-center items-center space-x-3 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500"><path d="M12 18.53A3.42 3.42 0 0 1 8.57 17a3.42 3.42 0 0 1 0-4.82 3.42 3.42 0 0 1 4.83 0 3.42 3.42 0 0 1 0 4.82Z"/><path d="M12 22a9.92 9.92 0 0 0 5-1.59"/><path d="M12 2v2.39"/><path d="M21.59 7.41 19.5 9.5"/><path d="M2.41 7.41 4.5 9.5"/><path d="m19.5 14.5-2.09 2.09"/><path d="m4.5 14.5 2.09 2.09"/><path d="M12 2a9.92 9.92 0 0 0-5 1.59"/><circle cx="12" cy="12" r="10"/></svg>
                <h1 className="text-3xl font-bold text-white">DroneFolio</h1>
            </div>
            <p className="text-gray-400">Admin Login</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            id="password"
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            autoFocus
          />
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          <div>
            <Button type="submit" className="w-full">
              Sign In
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;