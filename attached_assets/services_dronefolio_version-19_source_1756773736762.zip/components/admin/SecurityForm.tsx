import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import Input from '../ui/Input';
import Button from '../ui/Button';

const SecurityForm: React.FC = () => {
    const { updateAdminPassword } = useAppContext();
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (newPassword.length < 8) {
             setError("New password must be at least 8 characters long.");
            return;
        }

        if (newPassword !== confirmPassword) {
            setError("New passwords do not match.");
            return;
        }

        const passwordUpdated = updateAdminPassword(currentPassword, newPassword);

        if (passwordUpdated) {
            setSuccess("Password updated successfully!");
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
            setTimeout(() => setSuccess(''), 3000);
        } else {
            setError("Incorrect current password.");
        }
    };

    return (
        <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">Change Password</h3>
            {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-md text-center text-sm">{error}</p>}
            {success && <p className="text-green-400 bg-green-900/50 p-3 rounded-md text-center text-sm">{success}</p>}
            <form onSubmit={handleSubmit} className="space-y-6">
                <Input
                    id="current-password"
                    label="Current Password"
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    required
                    autoComplete="current-password"
                />
                <Input
                    id="new-password"
                    label="New Password (min. 8 characters)"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                    autoComplete="new-password"
                />
                <Input
                    id="confirm-password"
                    label="Confirm New Password"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    autoComplete="new-password"
                />
                <Button type="submit" className="w-full">
                    Update Password
                </Button>
            </form>
        </div>
    );
};

export default SecurityForm;