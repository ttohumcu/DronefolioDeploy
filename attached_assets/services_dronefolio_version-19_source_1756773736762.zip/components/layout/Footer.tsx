import React from 'react';
import { useAppContext } from '../../context/AppContext';

const XIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="currentColor"><path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/></svg>
);

const YouTubeIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="currentColor"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816Zm-10.615 12.816V8l6 4-6 4Z"/></svg>
);

const PersonalIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
);

const Footer: React.FC = () => {
  const { footerImageUrl, xUrl, youtubeUrl, personalUrl, setLoginModalOpen } = useAppContext();

  return (
    <footer 
      className="relative bg-cover bg-center text-white border-t border-gray-800"
      style={{ backgroundImage: `url(${footerImageUrl})` }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-60"></div>
      <div className="relative z-10">
        <div className="container mx-auto px-4 py-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Let's Create Something Breathtaking</h2>
          {(xUrl || youtubeUrl || personalUrl) && (
            <div className="flex items-center justify-center space-x-6">
                {xUrl && (
                    <a href={xUrl} target="_blank" rel="noopener noreferrer" aria-label="Follow on X" className="text-gray-400 hover:text-white transition-colors">
                       <XIcon />
                    </a>
                )}
                {youtubeUrl && (
                    <a href={youtubeUrl} target="_blank" rel="noopener noreferrer" aria-label="Subscribe on YouTube" className="text-gray-400 hover:text-white transition-colors">
                       <YouTubeIcon />
                    </a>
                )}
                {personalUrl && (
                    <a href={personalUrl} target="_blank" rel="noopener noreferrer" aria-label="Visit Personal Page" className="text-gray-400 hover:text-white transition-colors">
                       <PersonalIcon />
                    </a>
                )}
            </div>
          )}
        </div>
        <div className="bg-black bg-opacity-40 backdrop-blur-sm">
           <div className="container mx-auto px-4 py-4 flex justify-center items-center text-center text-gray-400 text-sm">
              <div>
                <span>&copy; {new Date().getFullYear()} DroneFolio. All rights reserved</span>
                <button 
                  onClick={() => setLoginModalOpen(true)} 
                  className="hover:text-white transition-colors duration-200 focus:outline-none rounded-sm focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-black/50"
                  aria-label="Admin Login"
                >
                  .
                </button>
              </div>
           </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;