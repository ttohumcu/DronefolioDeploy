import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../context/AppContext';
import { MediaItem, MediaType } from '../../types';
import PortfolioItem from './PortfolioItem';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import EditMediaModal from '../admin/EditMediaModal';
import ConfirmationModal from '../ui/ConfirmationModal';

const PortfolioGrid: React.FC = () => {
  const { mediaItems, selectedType, selectedLocation, deleteMediaItem } = useAppContext();
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [itemToEdit, setItemToEdit] = useState<MediaItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<MediaItem | null>(null);

  const handleItemClick = (item: MediaItem) => {
    setSelectedMedia(item);
  };

  const closeModal = () => {
    setSelectedMedia(null);
  };
  
  const handleEditClick = (item: MediaItem) => {
    setItemToEdit(item);
  };

  const handleDeleteClick = (item: MediaItem) => {
    setItemToDelete(item);
  };

  const confirmDelete = () => {
    if (itemToDelete) {
        deleteMediaItem(itemToDelete.id);
        setItemToDelete(null);
    }
  };

  const filteredItems = useMemo(() => {
    return mediaItems.filter(item => {
      const matchesSearch = 
        item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.title.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesType = selectedType === 'All' || item.type === selectedType;

      const matchesLocation = selectedLocation === 'All' || item.location === selectedLocation;

      return matchesSearch && matchesType && matchesLocation;
    });
  }, [mediaItems, searchTerm, selectedType, selectedLocation]);

  const groupedItems = useMemo(() => {
    return filteredItems.reduce((acc, item) => {
      if (!acc[item.type]) {
        acc[item.type] = [];
      }
      acc[item.type].push(item);
      return acc;
    }, {} as Record<MediaType, MediaItem[]>);
  }, [filteredItems]);

  const orderedTypes: MediaType[] = [
    MediaType.PHOTO_4K,
    MediaType.PANORAMA_180,
    MediaType.PANORAMA_360,
    MediaType.VIDEO,
  ];

  if (mediaItems.length === 0) {
    return (
      <div className="text-center py-20">
        <h2 className="text-4xl font-bold mb-2 text-white">Your Portfolio Awaits</h2>
        <p className="text-gray-400 text-lg">It looks a little empty here. Login as an admin to upload your first shot.</p>
      </div>
    );
  }

  return (
    <>
      <div className="mb-8 max-w-xl mx-auto">
        <Input 
          id="search"
          label="Search by Title or Location"
          type="text"
          placeholder="e.g. 'Coastal Cliffs' or 'Big Sur, California'"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredItems.length === 0 && (
         <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-2">No Results Found</h2>
          <p className="text-gray-400">Your search and filter criteria did not match any items.</p>
        </div>
      )}

      {orderedTypes.map(type => (
        groupedItems[type]?.length > 0 && (
          <section key={type} className="mb-16">
            <h2 className="text-3xl font-bold mb-6 border-b-2 border-gray-700 pb-3 text-white">{type}</h2>
            <div className="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-6 space-y-6">
              {groupedItems[type].map((item) => (
                <PortfolioItem 
                    key={item.id} 
                    item={item} 
                    onClick={() => handleItemClick(item)}
                    onEdit={handleEditClick}
                    onDelete={handleDeleteClick}
                />
              ))}
            </div>
          </section>
        )
      ))}
      
      <Modal isOpen={!!selectedMedia} onClose={closeModal} mediaItem={selectedMedia} />
      <EditMediaModal isOpen={!!itemToEdit} onClose={() => setItemToEdit(null)} mediaItem={itemToEdit} />
      <ConfirmationModal 
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={confirmDelete}
        title="Confirm Deletion"
        message={`Are you sure you want to permanently delete "${itemToDelete?.title}"? This action cannot be undone.`}
      />
    </>
  );
};

export default PortfolioGrid;
