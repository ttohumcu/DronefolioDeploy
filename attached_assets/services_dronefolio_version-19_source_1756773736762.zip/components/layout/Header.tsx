import React from 'react';
import { useAppContext } from '../../context/AppContext';
import Button from '../ui/Button';
import FilterBar from './FilterBar';

const DroneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="32" 
        height="32" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        className={className}
    >
        <circle cx="12" cy="12" r="2.5" />
        <path d="M12 12l7-7" />
        <path d="M12 12l-7 7" />
        <path d="M12 12l7 7" />
        <path d="M12 12l-7-7" />
        <circle cx="5" cy="5" r="1.5" />
        <circle cx="19" cy="5" r="1.5" />
        <circle cx="5" cy="19" r="1.5" />
        <circle cx="19" cy="19" r="1.5" />
    </svg>
);

const Header: React.FC = () => {
  const { isAuthenticated, logout, setUploadModalOpen, mediaItems } = useAppContext();

  return (
    <header className="bg-gray-900 bg-opacity-80 backdrop-blur-sm sticky top-0 z-40 border-b border-gray-800">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-3">
            <DroneIcon className="text-blue-500" />
            <h1 className="text-2xl font-bold text-white tracking-tight">DroneFolio</h1>
            <DroneIcon className="text-blue-500 transform scale-x-[-1]" />
        </div>
        <nav>
          {isAuthenticated && (
            <div className="flex items-center space-x-2">
              <Button onClick={() => setUploadModalOpen(true)} variant="primary" className="text-sm sm:text-base">
                Admin Settings
              </Button>
              <Button onClick={logout} variant="secondary" className="text-sm sm:text-base bg-red-600 hover:bg-red-700">
                Logout
              </Button>
            </div>
          )}
        </nav>
      </div>
      {mediaItems.length > 0 && <FilterBar />}
    </header>
  );
};

export default Header;