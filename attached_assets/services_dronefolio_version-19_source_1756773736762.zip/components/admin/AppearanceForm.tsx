import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import Button from '../ui/Button';

const AppearanceForm: React.FC = () => {
    const { setHeroImage, setFooterImage } = useAppContext();

    const [heroFile, setHeroFile] = useState<File | null>(null);
    const [heroError, setHeroError] = useState('');
    const [heroSuccess, setHeroSuccess] = useState('');
    
    const [footerFile, setFooterFile] = useState<File | null>(null);
    const [footerError, setFooterError] = useState('');
    const [footerSuccess, setFooterSuccess] = useState('');

    const handleFileChange = (
        e: React.ChangeEvent<HTMLInputElement>, 
        setFile: (file: File | null) => void, 
        setError: (error: string) => void, 
        setSuccess: (success: string) => void
    ) => {
        setSuccess('');
        setError('');
        const file = e.target.files?.[0];
        if (file) {
            setFile(file);
        }
    };
    
    const handleHeroFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        handleFileChange(e, setHeroFile, setHeroError, setHeroSuccess);
    };
    
    const handleFooterFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        handleFileChange(e, setFooterFile, setFooterError, setFooterSuccess);
    };

    const handleSubmit = async (
        e: React.FormEvent,
        file: File | null,
        setError: (error: string) => void,
        setSuccess: (success: string) => void,
        setImage: (file: File) => Promise<void>,
        setFile: (file: File | null) => void,
        inputId: string
    ) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (!file) {
            setError('Please select an image file first.');
            return;
        }

        try {
            await setImage(file);
            setSuccess('Image updated successfully!');
            setFile(null);
            const input = document.getElementById(inputId) as HTMLInputElement;
            if (input) input.value = '';
            setTimeout(() => setSuccess(''), 3000);
        } catch (error) {
            console.error("Image update failed:", error);
            setError('Failed to update image. Please try again.');
        }
    };
    
    const handleHeroSubmit = (e: React.FormEvent) => {
        handleSubmit(e, heroFile, setHeroError, setHeroSuccess, setHeroImage, setHeroFile, 'hero-file-upload');
    };
    
    const handleFooterSubmit = (e: React.FormEvent) => {
        handleSubmit(e, footerFile, setFooterError, setFooterSuccess, setFooterImage, setFooterFile, 'footer-file-upload');
    };

    return (
        <div className="space-y-8">
            <div>
                 <h3 className="text-xl font-bold mb-4 text-white">Customize Hero Image</h3>
                 {heroError && <p className="text-red-400 bg-red-900/50 p-3 rounded-md mb-4 text-center text-sm">{heroError}</p>}
                 {heroSuccess && <p className="text-green-400 bg-green-900/50 p-3 rounded-md mb-4 text-center text-sm">{heroSuccess}</p>}
                 <form onSubmit={handleHeroSubmit} className="space-y-4">
                     <div>
                        <label htmlFor="hero-file-upload" className="block text-sm font-medium text-gray-300 mb-1">
                            Background Image
                        </label>
                        <input id="hero-file-upload" type="file" accept="image/*" onChange={handleHeroFileChange} className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gray-600 file:text-white hover:file:bg-gray-500" />
                        {heroFile && (
                            <p className="mt-2 text-xs text-gray-400">Selected: {heroFile.name}</p>
                        )}
                     </div>
                     <Button type="submit" variant="secondary" className="w-full" disabled={!heroFile}>
                         Update Hero Image
                     </Button>
                 </form>
            </div>
    
            <div>
                 <h3 className="text-xl font-bold mb-4 text-white">Customize Footer Image</h3>
                 {footerError && <p className="text-red-400 bg-red-900/50 p-3 rounded-md mb-4 text-center text-sm">{footerError}</p>}
                 {footerSuccess && <p className="text-green-400 bg-green-900/50 p-3 rounded-md mb-4 text-center text-sm">{footerSuccess}</p>}
                 <form onSubmit={handleFooterSubmit} className="space-y-4">
                     <div>
                        <label htmlFor="footer-file-upload" className="block text-sm font-medium text-gray-300 mb-1">
                            Background Image
                        </label>
                        <input id="footer-file-upload" type="file" accept="image/*" onChange={handleFooterFileChange} className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gray-600 file:text-white hover:file:bg-gray-500" />
                        {footerFile && (
                            <p className="mt-2 text-xs text-gray-400">Selected: {footerFile.name}</p>
                        )}
                     </div>
                     <Button type="submit" variant="secondary" className="w-full" disabled={!footerFile}>
                         Update Footer Image
                     </Button>
                 </form>
            </div>
        </div>
    );
};

export default AppearanceForm;