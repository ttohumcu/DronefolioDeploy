import React, { useState, useEffect, useRef } from 'react';
import { MediaItem, MediaType } from '../../types';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  mediaItem: MediaItem | null;
}

const getYouTubeEmbedUrl = (url: string): string | null => {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? `https://www.youtube.com/embed/${match[2]}?autoplay=1` : null;
};


const Modal: React.FC<ModalProps> = ({ isOpen, onClose, mediaItem }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  // Zoom and Pan state
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [startDrag, setStartDrag] = useState({ x: 0, y: 0 });
  const [canPan, setCanPan] = useState(false);

  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Reset state when modal opens or media item changes
  useEffect(() => {
    if (isOpen) {
      setScale(1);
      setPosition({ x: 0, y: 0 });
      setIsDragging(false);
      setCanPan(false);
    }
  }, [isOpen, mediaItem]);

  // Effect to check if the image is larger than the container to enable panning
  useEffect(() => {
    if (!isOpen || !mediaItem || mediaItem.type === MediaType.VIDEO) {
      setCanPan(false);
      return;
    }

    const image = imageRef.current;
    const container = containerRef.current;
    if (!image || !container) return;

    const checkPannability = () => {
        if (!imageRef.current || !containerRef.current) return;
        
        const imageRenderedWidth = imageRef.current.naturalWidth * scale;
        const imageRenderedHeight = imageRef.current.naturalHeight * scale;
        const containerWidth = containerRef.current.clientWidth;
        const containerHeight = containerRef.current.clientHeight;
        
        const isPannable = imageRenderedWidth > containerWidth || imageRenderedHeight > containerHeight;
        setCanPan(isPannable);
    };

    // Check immediately for scale changes
    checkPannability();

    // Add listeners for async events like image load and window resize
    const handleLoadOrResize = () => checkPannability();
    image.addEventListener('load', handleLoadOrResize);
    window.addEventListener('resize', handleLoadOrResize);

    return () => {
        image.removeEventListener('load', handleLoadOrResize);
        window.removeEventListener('resize', handleLoadOrResize);
    };

  }, [isOpen, mediaItem, scale]);


  if (!isOpen || !mediaItem) return null;

  const isPhoto = mediaItem.type !== MediaType.VIDEO;
  const embedUrl = !isPhoto ? getYouTubeEmbedUrl(mediaItem.url) : null;

  // --- Handlers for Zoom and Pan ---
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPhoto || !canPan || e.button !== 0) return;
    e.preventDefault();
    setIsDragging(true);
    setStartDrag({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    e.preventDefault();
    setPosition({
      x: e.clientX - startDrag.x,
      y: e.clientY - startDrag.y,
    });
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    if (!isPhoto) return;
    e.preventDefault();
    const zoomFactor = 1.2;
    // Zoom in or out
    const newScale = e.deltaY < 0 ? scale * zoomFactor : scale / zoomFactor;
    
    // Clamp scale between 1 and a max value (e.g., 8)
    if (newScale >= 1 && newScale <= 8) {
      setScale(newScale);
    } else if (newScale < 1) {
      // If zooming out beyond 1, reset to 1 and center position
      setScale(1);
      setPosition({ x: 0, y: 0 });
    }
  };

  const handleZoomIn = () => setScale(s => Math.min(s * 1.5, 8));

  const handleZoomOut = () => {
    const newScale = Math.max(scale / 1.5, 1);
    setScale(newScale);
    if (newScale === 1) {
      setPosition({ x: 0, y: 0 });
    }
  };

  const handleReset = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };


  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 rounded-lg shadow-xl relative max-w-6xl w-full max-h-full overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 border-b border-gray-700 flex justify-between items-center z-20">
          <div>
            <h3 className="text-xl font-bold">{mediaItem.title}</h3>
            <p className="text-sm text-gray-400">{mediaItem.location} - <span className="font-semibold">{mediaItem.type}</span></p>
          </div>
          <button 
            onClick={onClose} 
            className="text-gray-400 hover:text-white transition-colors p-2 rounded-full"
            aria-label="Close"
          >
            {/* FIX: Corrected a typo in the viewBox attribute of the close icon SVG. */}
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>
        
        <div 
            ref={containerRef}
            className="flex-grow flex items-center justify-center overflow-hidden"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUpOrLeave}
            onMouseLeave={handleMouseUpOrLeave}
            onWheel={handleWheel}
        >
           {isPhoto ? (
             <img 
               ref={imageRef}
               src={mediaItem.url} 
               alt={mediaItem.title} 
               className="block select-none"
               style={{
                 transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
                 cursor: canPan ? (isDragging ? 'grabbing' : 'grab') : 'default',
                 transition: isDragging ? 'none' : 'transform 0.1s ease-out',
               }}
               draggable="false"
             />
           ) : (
             embedUrl ? (
                <div className="aspect-video w-full">
                   <iframe
                    src={embedUrl}
                    title={mediaItem.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  ></iframe>
                </div>
             ) : (
                <p>Invalid YouTube URL</p>
             )
           )}
        </div>

        {isPhoto && (
           <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm rounded-lg p-1 flex items-center space-x-1 z-20">
                <button onClick={handleZoomOut} disabled={scale <= 1} aria-label="Zoom out" className="p-2 text-white hover:bg-white/20 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
                <button onClick={handleReset} disabled={scale <= 1 && position.x === 0 && position.y === 0} aria-label="Reset zoom" className="p-2 text-white hover:bg-white/20 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 2v6h6"></path><path d="M21 12A9 9 0 0 0 6 5.3L3 8"></path><path d="M21 22v-6h-6"></path><path d="M3 12a9 9 0 0 0 15 6.7l3-2.7"></path></svg>
                </button>
                <button onClick={handleZoomIn} disabled={scale >= 8} aria-label="Zoom in" className="p-2 text-white hover:bg-white/20 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
           </div>
        )}
      </div>
    </div>
  );
};

export default Modal;