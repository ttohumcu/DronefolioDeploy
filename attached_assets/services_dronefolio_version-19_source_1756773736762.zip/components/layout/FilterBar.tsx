import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { MediaType } from '../../types';

const FilterBar: React.FC = () => {
    const { 
        selectedType, 
        setSelectedType, 
        selectedLocation, 
        setSelectedLocation, 
        locations 
    } = useAppContext();

    const filterTypes: { label: string; value: MediaType }[] = [
        { label: 'Photo', value: MediaType.PHOTO_4K },
        { label: '180°', value: MediaType.PANORAMA_180 },
        { label: '360°', value: MediaType.PANORAMA_360 },
        { label: 'Videos', value: MediaType.VIDEO },
    ];
    
    const baseButtonClasses = 'px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-blue-500';
    const activeButtonClasses = 'bg-blue-600 text-white';
    const inactiveButtonClasses = 'bg-gray-700 hover:bg-gray-600 text-gray-200';

    return (
        <div className="container mx-auto px-4 py-3 flex flex-wrap gap-4 items-center justify-between border-t border-gray-800">
            <div className="flex items-center space-x-2 flex-wrap gap-y-2">
                <button 
                    onClick={() => setSelectedType('All')}
                    className={`${baseButtonClasses} ${selectedType === 'All' ? activeButtonClasses : inactiveButtonClasses}`}
                    aria-pressed={selectedType === 'All'}
                >
                    All
                </button>
                {filterTypes.map(filter => (
                    <button 
                        key={filter.value} 
                        onClick={() => setSelectedType(filter.value)}
                        className={`${baseButtonClasses} ${selectedType === filter.value ? activeButtonClasses : inactiveButtonClasses}`}
                        aria-pressed={selectedType === filter.value}
                    >
                        {filter.label}
                    </button>
                ))}
            </div>
            
            {locations.length > 0 && (
                 <div className="relative">
                    <select
                        value={selectedLocation}
                        onChange={(e) => setSelectedLocation(e.target.value)}
                        className="w-full sm:w-64 bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none"
                        aria-label="Filter by location"
                    >
                        <option value="All">All Locations</option>
                        {locations.map(loc => (
                            <option key={loc} value={loc}>{loc}</option>
                        ))}
                    </select>
                     <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                        <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                    </div>
                </div>
            )}
        </div>
    );
};

export default FilterBar;
